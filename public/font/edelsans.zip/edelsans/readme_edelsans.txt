- "EDELSANS"
-
-
> > >  (c) 2009 Jakob Runge 
-
-
> > >  free for non-commercial use
> > >  type designer must be attributed
> > >  for further use, contact the type designer
-
-
> > >  http://26plus-zeichen.de/fonts/edelsans/  
-
-
> > >  Contakt: jakob@26plus-zeichen.de  
-
-
> awaiting an image/ a pdf of the font-in-use :-)!


